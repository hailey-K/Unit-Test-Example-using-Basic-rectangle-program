﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Assignment01;

namespace Assignment01.Tests
{
    [TestFixture]
    public class RectangleTest
    {
        [Test()]
        public void TestGetLength_Length6_Expect6()
        {
            Rectangle rc = new Rectangle();
            rc.SetLength(6);
            Assert.AreEqual(6, rc.GetLength());
        }
        [Test()]
        public void TestSetLength_Length5_Expect5()
        {
            Rectangle rc = new Rectangle();
            rc.SetLength(5);
            Assert.AreEqual(5, rc.GetLength());
        }
        [Test()]
        public void TestGetWidth_Width7_Expect7()
        {
            Rectangle rc = new Rectangle();
            rc.SetWidth(7);
            Assert.AreEqual(7, rc.GetWidth());
        }
        [Test()]
        public void TestSetWidth_Width6_Expect6()
        {
            Rectangle rc = new Rectangle();
            rc.SetWidth(6);

            Assert.AreEqual(6, rc.GetWidth());
        }
        [Test()]
        public void TestGetPerimeter_Perimeter12_Expect12()
        {
            Rectangle rc = new Rectangle(1,5);
            Assert.AreEqual(12, rc.GetPerimeter());
        }
        [Test()]
        public void TestGetArea_Area21_Expect21()
        {
            Rectangle rc = new Rectangle(3,7);
            Assert.AreEqual(21, rc.GetArea());
        }
    }
}
