﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment01
{
    class Program
    {
        static void Main(string[] args)
        {
            bool loopRunning = true;
            string userInput = "";
            int userChoice = 0;
            Rectangle rec = new Rectangle();
            while (loopRunning)
            {
                if (userChoice == 0) // Get length and width
                {
                    while (true)
                    {
                        Console.WriteLine("Please enter length and height. eg) 1,2");
                        userInput = Console.ReadLine();
                        if (!userInput.Contains(","))
                        {
                            Console.WriteLine("Please use the correct form. eg) 1,2");
                        }
                        else
                        {
                            string[] userTempInput = new string[2];
                            userTempInput = userInput.Split(',');
                            if (VerifyStringAsNumber(userTempInput[0], "length") && VerifyStringAsNumber(userTempInput[1], "width"))
                            {
                                rec = new Rectangle(int.Parse(userTempInput[0]), int.Parse(userTempInput[1]));
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Please enter number only.");
                            }
                        }
                    }
                }
                else if (userChoice == 1) //Get Rectangle Length
                {
                    Console.WriteLine("Length : " + rec.GetLength());
                }
                else if (userChoice == 2) //Change Rectangle Length
                {
                    while (true)
                    {
                        Console.WriteLine("Please enter the length.");
                        userInput = Console.ReadLine();
                        if (VerifyStringAsNumber(userInput, "length"))
                        {
                            rec.SetLength(int.Parse(userInput));
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Please enter number only.");
                        }
                    }
                }
                else if (userChoice == 3) //Get Rectangle Width
                {
                    Console.WriteLine("Width : " + rec.GetWidth());
                }
                else if (userChoice == 4) //Change Rectangle Width
                {
                    while (true)
                    {
                        Console.WriteLine("Please enter the Width.");
                        userInput = Console.ReadLine();
                        if (VerifyStringAsNumber(userInput, "length"))
                        {
                            rec.SetWidth(int.Parse(userInput));
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Please enter number only.");
                        }
                    }
                }
                else if (userChoice == 5) //Get Rectangle Perimeter
                {
                    Console.WriteLine("Perimeter : " + rec.GetPerimeter());
                }
                else if (userChoice == 6) //Get Rectangle Area
                {
                    Console.WriteLine("Area : " + rec.GetArea());
                }
                else if (userChoice == 7) //Exit
                {
                    loopRunning = false;
                    break;
                }
                else
                {
                    Console.WriteLine("Please put the number between 1 and 7, inclusive.");
                }
                Console.WriteLine("1. Get Rectangle Length");
                Console.WriteLine("2. Change Rectangle Length");
                Console.WriteLine("3. Get Rectangle Width");
                Console.WriteLine("4. Change Rectangle Width");
                Console.WriteLine("5. Get Rectangle Perimeter");
                Console.WriteLine("6. Get Rectangle Area");
                Console.WriteLine("7. Exit");

                string userInputTemp = Console.ReadLine();
                bool verify = int.TryParse(userInputTemp, out userChoice);
                if (!verify)
                {
                    userChoice = 8;
                }
                Console.Clear();
            }
        }
        static bool VerifyStringAsNumber(string number, string type)
        {
            int n;
            bool verify = int.TryParse(number, out n);

            if (verify && n < 0)
            {
                Console.WriteLine(type + " should be greater than 0.");
                verify = false;
            }

            return verify;
        }
    }
}
